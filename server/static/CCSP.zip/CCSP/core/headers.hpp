#ifndef HEADERS_H
#define HEADERS_H

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <limits>
#include <queue>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <string>
#include <string.h>
#include <math.h>
#include <malloc.h>
#include <functional>
#include <tuple>

#include "core/time.hpp"

using namespace std;

#endif
