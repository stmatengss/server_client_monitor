#ifndef MSTORE_H
#define MSTORE_H

#include "core/headers.hpp"

class MStore{

public:
	MStore();
	~MStore();
	/*public interface, don't modify!!*/
	void preprocessing(std::string input);
	float queryAverageIncome(int city, int startAge, int endAge);
	vector<int> queryIncomeTopK(int city, int k);
	vector<int> queryMedianIncomes(vector<int> cities, int startAge, int endAge);

private:
	/*Your private variables*/

private:
	/*Your private functions*/
};

/*Interface implementation*/
inline MStore::MStore(){
}

inline void MStore::preprocessing(std::string input){
}

inline float MStore::queryAverageIncome(int city, int startAge, int endAge){
	return 0.0f;
}

inline vector<int> MStore::queryIncomeTopK(int city, int k){
	vector<int> result;
	return result;
}

inline vector<int> MStore::queryMedianIncomes(vector<int> cities, int startAge, int endAge){
	vector<int> result;
	return result;
}

/*Private function*/
inline MStore::~MStore(){
}

#endif
