#include "core/mstore.hpp"

int main(int argc, char ** argv){
	std::string input = "";
	int opt = 0;
	while ((opt = getopt(argc, argv, "i:")) != -1) {
		switch(opt) {
			case 'i':
				input = optarg;
			break;
		}
	}

	if (input == "") {
		fprintf(stderr, "driver -i [input file path]\n");
		exit(-1);
	}
	MStore ms;

	double start_time = get_time();
	printf("average %f\n", ms.queryAverageIncome(1000, 18, 30));
	printf("Query average income time is %.2lf\n", get_time() - start_time);

	start_time = get_time();
	std::vector<int> incomes = ms.queryIncomeTopK(1000, 10);
	printf("Query income top k time is %.2lf\n", get_time() - start_time);

	int cites[] = {1000,1002,1003};
	vector<int> citesVec(cites, cites + sizeof(cites)/sizeof(int));
	start_time = get_time();
	ms.queryMedianIncomes(citesVec, 20, 40);
	printf("Query median income time is %.2lf\n", get_time() - start_time);

	return 0;
}
